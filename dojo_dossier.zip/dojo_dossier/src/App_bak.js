import React, { Component } from 'react';
// import logo from './logo.svg';
import './App.css';
import './ui-toolkit/css/nm-cx/main.css';

import { connect } from 'react-redux'
import { addNameToState, addItemToState, setTabToState } from './state/actions';

class App extends Component {
  constructor(props) {
    super(props)

    this.state = {
      appName: '',
      appItem: '',
      appTabState: ''
    }
  }

  render() {
    return (
      <div className="App app-col">
        <span className="block bg-light-grey padding-medium margin-bottom-medium text-left">Dojo Dossier</span>
        <div className="app-col">
            <input
              type="text"
              placeholder="Add a new tab"
              className="md-text-field"
              onChange={(e) => this.setState({ appName: e.target.value })}
              value={this.state.appName} />
            <button
              className="block tertiary button btn-cta tiny"
              onClick={(e) => { this.props.addName(this.state.appName) }}>
              Add Tab
            </button>
        </div>
        <div className="app-col">
          <ul className="button-group btn-cta tiny">
            {this.props.name.map((x, idx) => {
              return (
                <li key={'li_name' + idx}>
                  <button key={'btn_name' + idx}>{x}</button>
                </li>
              )
            })}
          </ul>
        </div>
        <div className="app-col text-left card">
          <ul>
            {this.props.item.map((x, idx) => {
              return ( <li key={'item' + idx}>{x}</li> )
            })}
          </ul>
          <input
            type="text"
            placeholder="Add a new item to the list"
            className="md-text-field"
            onChange={(e) => this.setState({ appItem: e.target.value })}
            value={this.state.appItem} />
          <button
            className="block tertiary button btn-cta tiny"
            onClick={(e) => { this.props.addItem(this.state.appItem) }}>
            Add Item
          </button>
        </div>
      </div>
    )
  }
}

const getStateFromReduxPassToAppComponentAsProps = (state) => {
  return {
    appName: state.iStateNames,
    appItem: state.iStateItems,
    appTabState: state.iStateTabs
  }
}

const getDispatchFromReduxToAppComponentAsProps = (dispatch) => {
  return {
    addName(dispatchName) {
      dispatch(addNameToState(dispatchName))
    },
    addItem(dispatchItem) {
      dispatch(addItemToState(dispatchItem))
    },
    addTabState(dispatchTabState) {
      dispatch(setTabToState(dispatchTabState))
    }
  }
}

export default connect(getStateFromReduxPassToAppComponentAsProps, getDispatchFromReduxToAppComponentAsProps)(App)
