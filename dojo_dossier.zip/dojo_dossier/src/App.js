import React, { Component } from 'react';
// import logo from './logo.svg';
import './App.css';
import './ui-toolkit/css/nm-cx/main.css';

import { connect } from 'react-redux'
import { addNameToState, addItemToState, setTabToState, filterItemToState, filterNameToState } from './state/actions';

class App extends Component {
  constructor(props) {
    super(props)

    this.state = {
      appNames: '',
      appTabItems: '',
      appSetTab: '',
      appFilterName: '',
      appFilterItem: ''
    }
    this.displayTabs = this.displayTabs.bind(this)
    this.displayInfo = this.displayInfo.bind(this)
  }

  displayTabs(props) {
    return(
      <div>
        <div className="app-col">
          <input
            type="text"
            placeholder="Add a new tab"
            className="md-text-field"
            value={this.props.appFilterName}
            onChange={(e) => { this.props.filterName(e.target.value) }} />
          <button
            className="block tertiary button btn-cta tiny"
            onClick={(e) => { this.props.appFilterName.trim() !== '' && this.props.addName() }}>
            Add Tab
          </button>
        </div>
        <div className="app-col">
          <ul className="button-group btn-cta tiny">
            {this.props.appNames.map((x, idx) => {
              return (
                <li key={'li_name' + idx}>
                  <button
                    key={'btn_name' + idx}
                    value={idx}
                    onClick={(e) => { this.props.setTab(e.target.value) }}>
                    {x.name}
                  </button>
                </li>
              )
            })}
          </ul>
        </div>
      </div>
    )
  }

  displayInfo(props) {
    return (
      <div className="app-col text-left card">
        <ul>
          {this.props.appSetTab !== '' && this.props.appTabItems.map((x, idx) => {
            return (
              <li key={'item' + idx}>
                {x}
              </li>
            )
          })}
        </ul>
        <input
          type="text"
          placeholder="Add a new item to the list"
          className="md-text-field"
          value={this.props.appFilterItem}
          onChange={(e) => { this.props.filterItem(e.target.value) }} />
        <button
          className="block tertiary button btn-cta tiny"
          onClick={(e) => { if(this.props.appFilterItem.trim() !== '' && this.props.appSetTab !== '') this.props.addItem() }}>
          Add Item
        </button>
      </div>
    )
  }

  render() {
    return (
      <div className="App app-col">
        <span className="block bg-light-grey padding-medium margin-bottom-medium text-left">Dojo Dossier</span>
        {this.displayTabs()}
        {this.displayInfo()}
      </div>
    )
  }
}

const getStateFromReduxPassToAppComponentAsProps = (state) => {
  return {
    appNames: state.iStateNames,
    appTabItems: state.iTabItems,
    appSetTab: state.iSetTab,
    appFilterName: state.iFilterName,
    appFilterItem: state.iFilterItem
  }
}

const getDispatchFromReduxToAppComponentAsProps = (dispatch) => {
  return {
    addName(dispatchName) {
      dispatch(addNameToState(dispatchName))
    },
    addItem(dispatchItem) {
      dispatch(addItemToState(dispatchItem))
    },
    setTab(dispatchTabState) {
      dispatch(setTabToState(dispatchTabState))
    },
    filterItem(dispatchFilterItem) {
      dispatch(filterItemToState(dispatchFilterItem))
    },
    filterName(dispatchFilterName) {
      dispatch(filterNameToState(dispatchFilterName))
    }
  }
}

export default connect(getStateFromReduxPassToAppComponentAsProps, getDispatchFromReduxToAppComponentAsProps)(App)
