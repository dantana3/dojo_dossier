import React, { Component } from 'react';
// import logo from './logo.svg';
import './App.css';
import './ui-toolkit/css/nm-cx/main.css';

import { connect } from 'react-redux'
import { addNameToState, addItemToState, setTabToState } from './state/actions';

// function TabCard(props) {
//   const desc = props.activity.map((arr, i) => <span key={i}>{arr.desc}</span>)
//   return(<div>Hi</div>)
// }
// <TabCard activity={this.state.pers_activity}/>

class App extends Component {
  constructor(props) {
    super(props)

    this.state = {
      name: '',
      item: '',
      tab_state: ''
    }
  }

  render() {
    return (
      <div className="App app-col">
        <span className="block bg-light-grey padding-medium margin-bottom-medium text-left">Dojo Dossier</span>
        <div className="app-col">
            <input
              type="text"
              placeholder="Add a new tab"
              className="md-text-field"
              onChange={(e) => this.setState({ name: e.target.value })}
              value={this.state.name} />
            <button
              className="block tertiary button btn-cta tiny"
              onClick={(e) => { this.props.addName(this.state.name) }}>
              Add Tab
            </button>
        </div>
        <div className="app-col">
          <ul className="button-group btn-cta tiny">
            {this.props.name.map((name, idx) => {
              return (
                <li key={'li_name' + idx}>
                  <button key={'btn_name' + idx}>{name}</button>
                </li>
              )
            })}
          </ul>
        </div>
        <div className="app-col text-left card">
          <ul>
            {this.props.item.map((item, idx) => {
              return ( <li key={'item' + idx}>{item}</li> )
            })}
          </ul>
          <input
            type="text"
            placeholder="Add a new item to the list"
            className="md-text-field"
            onChange={(e) => this.setState({ item: e.target.value })}
            value={this.state.item} />
          <button
            className="block tertiary button btn-cta tiny"
            onClick={(e) => { this.props.addItem(this.state.item) }}>
            Add Item
          </button>
        </div>
      </div>
    )
  }
}

const getStateFromReduxPassToAppComponentAsProps = (state) => {
  return {
    name: state.names,
    item: state.items,
    tab_state: state.tab_states
  }
}

const getDispatchFromReduxToAppComponentAsProps = (dispatch) => {
  return {
    //addName: function (name) { (same as below)
    addName(name) {
      dispatch(addNameToState(name))
    },
    addItem(item) {
      dispatch(addItemToState(item))
    },
    addTabState(tab_state) {
      dispatch(setTabToState(tab_state))
    }
  }
}

export default connect(getStateFromReduxPassToAppComponentAsProps, getDispatchFromReduxToAppComponentAsProps)(App)
