import { ADD_NAME, ADD_ITEM, SET_TAB } from './actions'

const intialState = {
  names: [
    'Sally',
    'Jim',
    'Gemma',
    'Arthur',
    'Heath'
  ],
  items: [
    'Great listener',
    'Owns a pet python',
    'Played vollyball in college'
  ],
  tab_states: [
    ''
  ]
}

function reducer(state=intialState, action) {
  switch(action.type) {
    case ADD_NAME:
      return {...state, names: state.names.concat([action.payload])}
    case ADD_ITEM:
      return {...state, items: state.items.concat([action.payload])}
    case SET_TAB:
      return {...state, tab_states: state.tab_states}
    default:
      return state;
  }
}

export default reducer;