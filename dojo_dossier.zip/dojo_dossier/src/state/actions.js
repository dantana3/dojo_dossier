export const ADD_NAME = 'ADD_NAME'
export const ADD_ITEM = 'ADD_ITEM'
export const SET_TAB = 'SET_TAB'
export const FILTER_ITEM = 'FILTER_ITEM'
export const FILTER_NAME = 'FILTER_NAME'

export const addNameToState = (payload) => {
  return {type: ADD_NAME, payload}
};

export const addItemToState = (payload) => {
  return {type: ADD_ITEM, payload}
};

export const setTabToState = (payload) => {
  return {type: SET_TAB, payload}
}

export const filterItemToState = (payload) => {
  return {type: FILTER_ITEM, payload}
}

export const filterNameToState = (payload) => {
  return {type: FILTER_NAME, payload}
}