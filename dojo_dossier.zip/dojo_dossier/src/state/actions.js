export const ADD_NAME = 'new name'
export const ADD_ITEM = 'add item'
export const SET_TAB = 'tab state'

export const addNameToState = (payload) => {
  return {type: ADD_NAME, payload}
};

export const addItemToState = (payload) => {
  return {type: ADD_ITEM, payload}
};

export const setTabToState = (payload) => {
  return {type: SET_TAB, payload}
}