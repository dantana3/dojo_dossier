import { ADD_NAME, ADD_ITEM, SET_TAB, FILTER_ITEM, FILTER_NAME } from './actions'

const intialState = {
  iStateNames: [
    {name: 'Sally', id: 0},
    {name: 'Jim', id: 1},
    {name: 'Gemma', id: 2},
    {name: 'Arthur', id: 3},
    {name: 'Heath', id: 4}
  ],
  iStateItems: [
    {id: 0, itemlist: ['I like to bowl']},
    {id: 1, itemlist: ['Golfing is fun']},
    {id: 2, itemlist: ['Cooking is the best']},
    {id: 3, itemlist: ['I have a dog']},
    {id: 4, itemlist: [
      'Great listener',
      'Owns a pet python',
      'Played vollyball in college']}
  ],
  iTabItems: [],
  iUserId: 4,
  iSetTab: '',
  iFilterName: '',
  iFilterItem: ''
}

function reducer(state=intialState, action) {
  switch(action.type) {
    case ADD_NAME:
      let newId = state.iUserId + 1
      let newName = state.iFilterName
      return {
        ...state,
        iStateNames: state.iStateNames.concat([{name: newName, id: newId}]),
        iStateItems: state.iStateItems.concat([{id: newId, itemlist: []}]),
        iTabItems: [],
        iUserId: newId,
        iSetTab: newId,
        iFilterName: ''
      }
    case ADD_ITEM:
      let newItem = state.iFilterItem
      console.log(state.iStateItems[state.iSetTab])
      return {
        ...state,
        // *************************************************************************************
        // STATE ITEM LIST IS GETTING TRASHED WHEN ADDING AN ITEM
        // *************************************************************************************
        iStateItems: state.iStateItems[state.iSetTab].itemlist.concat(newItem),
        // *************************************************************************************
        iTabItems: state.iTabItems.concat(newItem),
        iFilterItem: ''
      }
    case SET_TAB:
      let reducedItemList = state.iStateItems[action.payload].itemlist
      return {
        ...state,
        iTabItems: reducedItemList,
        iSetTab: action.payload
      }
    case FILTER_ITEM:
      return {
        ...state,
        iFilterItem: action.payload
      }
    case FILTER_NAME:
      return {
        ...state,
        iFilterName: action.payload
      }
    default:
      return state;
  }
}

export default reducer;